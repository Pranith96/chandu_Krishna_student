package in.demo.design.pattern;

public class OperatingSystemFactory {

	public OperatingSystem getOPeratingSystem(String str) {

		if (str.equalsIgnoreCase("ANDRIOD")) {
			return new AndriodOs();
		} else if (str.equalsIgnoreCase("WINDOWS")) {
			return new WindowsOs();
		} else if (str.equalsIgnoreCase("IOS")) {
			return new IOSOs();
		} else
			return null;

	}
}
