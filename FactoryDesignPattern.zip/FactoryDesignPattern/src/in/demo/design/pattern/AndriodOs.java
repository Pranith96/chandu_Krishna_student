package in.demo.design.pattern;

public class AndriodOs implements OperatingSystem {

	public void specification() {

		System.out.println("Andriod operating system");
	}

}
