package in.demo.design.pattern;

public class WindowsOs implements OperatingSystem{

	public void specification() {

		System.out.println("Windows Operating System");
	}

}
