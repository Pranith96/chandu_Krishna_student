package in.demo.design.pattern;

public class IOSOs implements OperatingSystem{

	public void specification() {

		System.out.println("IOS operating system");
	}

}
