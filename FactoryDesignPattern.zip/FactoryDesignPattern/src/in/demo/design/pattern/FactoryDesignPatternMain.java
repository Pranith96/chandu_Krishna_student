package in.demo.design.pattern;

import java.util.Scanner;

public class FactoryDesignPatternMain {

	public static void main(String args[]) {

		// normal form of execution
		/*
		 * OperatingSystem osW = new WindowsOs(); OperatingSystem osA = new AndriodOs();
		 * OperatingSystem osI = new IOSOs(); osW.specification(); osA.specification();
		 * osI.specification();
		 */
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		OperatingSystemFactory opsf = new OperatingSystemFactory();
		OperatingSystem os = opsf.getOPeratingSystem(str);
		os.specification();
	
	}

}
