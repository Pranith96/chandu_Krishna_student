package in.demo.design.pattern;

public interface OperatingSystem {
	
	void specification();

}
