
public class Addition {

	public void add() {
		System.out.println("Add");
	}

	public void sum() {
		System.out.println("sum");
	}

}
