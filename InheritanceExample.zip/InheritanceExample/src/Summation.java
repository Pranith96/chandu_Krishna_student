
public class Summation extends Addition {

	public void sub() {
		System.out.println("Sub");
	}

	public void hello() {
		System.out.println("Hello");
	}
	
	public void data(int i, int j) {
		int k = i+j;
		System.out.println(k);
	}
	
}
