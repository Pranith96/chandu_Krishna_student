
public class MainExample {

	public static void main(String[] args) {

		Summation sum = new Summation();
		sum.sub();
		sum.hello();
		sum.add();
		sum.sum();
		sum.data(6, 4);

	}

}
