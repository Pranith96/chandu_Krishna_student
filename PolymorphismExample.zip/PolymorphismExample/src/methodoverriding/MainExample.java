package methodoverriding;

public class MainExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Addition addition = new Addition();
		addition.add(10, 5);
		
		Calculation addition1 = new Addition();
		addition1.add(10, 5);
		
	}

}
