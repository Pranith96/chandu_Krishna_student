package methodoverriding;

public class Calculation {

	public void add(int a, int b) {
		System.out.println(a+b);
	}
}
