package methodoverriding;

public class Addition extends Calculation{

	public void add(int a, int b) {
		System.out.println(a-b);
	}
}
