
public class Methodoverloadmain {

	public static void main(String[] args) {
		MethodOverloadingExample methodOverloadingExample = new MethodOverloadingExample();
		methodOverloadingExample.add(5, 5);
		methodOverloadingExample.add(5, 5, 5);
		methodOverloadingExample.add(10L, 10L, 10L);
	}
}
