
public class UnaryOperatorExample1 {

	public static void main(String[] args) {

		int x = 50;
		
		System.out.println(x++); // 50

		System.out.println(++x); // 52

		int y = x;
		System.out.println(y);
		
		
		System.out.println(x--); //52
		System.out.println(--x); //50
	}

}
