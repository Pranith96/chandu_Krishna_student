
public class UnaryOperatorExample3 {

	public static void main(String[] args) {

		int a = 20;
		int b = -20;

		boolean c = true;
		boolean d = false;

		System.out.println(~a); // -21
		System.out.println(~b);// 19
		System.out.println(!c); // false
		System.out.println(!d);// true

	}
}
