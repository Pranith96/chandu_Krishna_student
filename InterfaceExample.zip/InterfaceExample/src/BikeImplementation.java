
public class BikeImplementation implements Bike {

	public void breaks() {
		System.out.println("Breaks");
	}

	public void engine() {
		System.out.println("engine");

	}

	public void seat() {
		System.out.println("seat");

	}

	public void petrolEngine() {
		System.out.println("petrol engine");

	}

	public void tires() {
		System.out.println("tires");
	}
	
	public void light() {
		System.out.println("lights");
	}
}
