
public class BikeImplementation2 implements Bike {

	public void breaks() {
		System.out.println("Breaks1");
	}

	public void engine() {
		System.out.println("engine1");

	}

	public void seat() {
		System.out.println("seat1");

	}

	public void petrolEngine() {
		System.out.println("petrol engine1");

	}

	public void tires() {
		System.out.println("tires1");
	}

	public void light() {
		System.out.println("lights1");
	}
}
