
public class BikeMain {

	public static void main(String[] args) {

		BikeImplementation bike = new BikeImplementation();
		bike.breaks();
		bike.engine();
		bike.petrolEngine();
		bike.seat();
		bike.tires();
		bike.light();
		
		BikeImplementation2 bike2 = new BikeImplementation2();
		bike2.breaks();
		bike2.engine();
		bike2.petrolEngine();
		bike2.seat();
		bike2.tires();
		bike2.light();
		
		Bike bike3  = new BikeImplementation();
		bike3.breaks();
		bike3.engine();
		bike3.petrolEngine();
		bike3.seat();
		bike3.tires();
		bike3.light();
	}
}
