public interface Bike {

	public void engine();

	public void breaks();

	public void petrolEngine();

	public void tires();

	public void seat();

	public void light();
}
