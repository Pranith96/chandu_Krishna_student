
public class WhileLoopExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		while (i <= 10) {
			System.out.println(i);
			i++;
		}

		// infinite loop
//		while(true) {
//			System.out.println("Hi");
//		}

	}

}
