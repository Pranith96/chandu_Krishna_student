package com.in.modifers;

import com.in.access.Addition;

public class Summation extends Addition {

	public static void main(String[] args) {
		Summation addition = new Summation();
		addition.add();
		addition.hi();
	}
}
