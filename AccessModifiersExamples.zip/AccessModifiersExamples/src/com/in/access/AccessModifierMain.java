package com.in.access;

public class AccessModifierMain {

	public static void main(String[] args) {

		Addition addition = new Addition();
		addition.add();
		addition.hi();
		addition.print();
	}

}
