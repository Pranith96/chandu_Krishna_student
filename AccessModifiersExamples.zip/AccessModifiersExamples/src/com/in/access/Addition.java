package com.in.access;

public class Addition {

	public void add() {
		System.out.println("Additions");
		hello();
	}

	private void hello() {
		System.out.println("Hello");
	}

	protected void hi() {
		System.out.println("Hi");
	}

	void print() {
		System.out.println("Print");
	}
}
