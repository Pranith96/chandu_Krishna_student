package in.factory.design.pattern;

import java.io.IOException;
import java.util.Scanner;

import in.factory.design.pattern.bank.Plan;
import in.factory.design.pattern.getplanfactory.GetPlanFactory;

public class FactoryMain {

	public static void main(String args[]) throws IOException {

		GetPlanFactory planFactory = new GetPlanFactory();
		System.out.println("Enter the plan:");
		Scanner sc = new Scanner(System.in);

		String str = sc.nextLine();

		Plan plan = planFactory.getPlan(str);

		System.out.print("Enter the number of units for bill will be calculated: ");

		int units = sc.nextInt();
		
		plan.calculate(units);

	}

}
