package in.factory.design.pattern.getplanfactory;

import in.factory.design.pattern.bank.Plan;
import in.factory.design.pattern.plan.CommercialPlan;
import in.factory.design.pattern.plan.DomesticPlan;
import in.factory.design.pattern.plan.InstitutePlan;

public class GetPlanFactory {

	public Plan getPlan(String str) {

		if (str.equalsIgnoreCase("DOMESTIC")) {
			return new DomesticPlan();
		} else if (str.equalsIgnoreCase("COMMERCIAL")) {
			return new CommercialPlan();
		} else if (str.equalsIgnoreCase("INSTITUTION")) {
			return new InstitutePlan();
		}
		return null;

	}

}
