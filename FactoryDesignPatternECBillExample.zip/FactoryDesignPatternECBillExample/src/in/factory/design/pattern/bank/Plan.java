package in.factory.design.pattern.bank;

public interface Plan {

	public void calculate(int units);

}
