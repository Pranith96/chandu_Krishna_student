package in.factory.design.pattern.plan;

import in.factory.design.pattern.bank.Plan;

public class CommercialPlan implements Plan {

	@Override
	public void calculate(int units) {

		double rateOfBill = 3.5;

		System.out.println("Commercial plan: " + rateOfBill * units);

	}

}
