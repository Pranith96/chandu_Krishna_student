package in.factory.design.pattern.plan;

import in.factory.design.pattern.bank.Plan;

public class DomesticPlan implements Plan{

	@Override
	public void calculate(int units) {

		double rateOfBill = 2.5;
		
		System.out.println("Domestic plan Bill: " +rateOfBill*units);
	}
	

}
