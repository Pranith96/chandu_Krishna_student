package in.factory.design.pattern.plan;

import in.factory.design.pattern.bank.Plan;

public class InstitutePlan implements Plan {

	@Override
	public void calculate(int units) {

		double rateOfBill = 3.0;

		System.out.println("Institute Plan: " + rateOfBill * units);
	}

}
