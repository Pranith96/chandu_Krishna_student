
public class BikeLatestModel extends BikeNewModel {

	public void petrolEngine() {
		System.out.println("Bike Petrol");
	}

}
