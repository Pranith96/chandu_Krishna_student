
public class BikeMain {

	public static void main(String[] args) {

		BikeLatestModel model = new BikeLatestModel();
		model.breaks();
		model.engine();
		model.petrolEngine();
		model.seat();
		model.tires();
	}
}
