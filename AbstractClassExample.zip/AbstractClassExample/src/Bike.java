
public abstract class Bike {

	public abstract void tires();

	public abstract void breaks();

	public void engine() {
		System.out.println("Bike engine");
	}
}
