
public class UserDefinedRuntimeException extends RuntimeException {

	public UserDefinedRuntimeException(String message) {
		super(message);
	}
}
