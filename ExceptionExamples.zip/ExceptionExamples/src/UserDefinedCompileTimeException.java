

public class UserDefinedCompileTimeException extends Exception {

	public UserDefinedCompileTimeException(String message) {
		super(message);
	}
}
